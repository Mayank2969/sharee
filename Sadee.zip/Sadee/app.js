const express =  require('express');
const path = require('path');
const fs = require('fs')
const mongoose = require('mongoose');
const validator = require('validator');
const bodyparser = require('body-parser');
const middleware = require('./mid');
mongoose.connect('mongodb://localhost:27017/swap', {useNewUrlParser: true , useUnifiedTopology: true});
const app = express();
const port = 8000;

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {
  // we're connected!
//   console.log("we are connected")
});

const kittySchema = new mongoose.Schema({
    userName:{
       type: String,
       required:true,
       unique:true
    },
       
    firstName:{
        type:String,
        maxlength:12
    } ,

    lastName:{
        type: String,
        maxlength:12
    },
    email:{
        type:String,
        required:true,
        unique:true
        // validate(val){
        //     if (validator.isEmail(val)){
        //         throw new Error("Email is not valid");
        //     }
        // }
    } ,
    Gender:String,
    isSeller:String,
    isAdmin:String,
    isCustomer:String,
    Passward:{
      type:String,
      required:true ,
      maxlength:8
    },
    History: String
  });

const Contact = mongoose.model('Contact', kittySchema);

app.use('/static', express.static('static')) // For serving static files
app.use(express.urlencoded())

// PUG SPECIFIC STUFF
app.engine('pug', require('pug').__express);
app.set('view engine', 'pug') // Set the template engine as pug
app.set('views', path.join(__dirname, 'views')) // Set the views directory
 
// ENDPOINTS
app.get('/', (req, res)=>{
    const params = {}
    res.status(200).render('index.pug', params);
})
app.post('/',middleware, (req, res)=>{
    var myData = new Contact(req.body);
    console.log(myData);
    myData.save().then(()=>{
    res.send('This item has been saved to the database')
    }).catch(()=>{
    res.status(400).send('item was not saved to the databse')
})
})

app.listen(port, ()=>{
    console.log(`The application started successfully on port ${port}`);
})

module.exports  = Contact;