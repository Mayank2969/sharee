// const mongoose = require('mongoose');
// const validator = require('validator');
// mongoose.connect('mongodb://localhost:27017/swap', {useNewUrlParser: true , useUnifiedTopology: true});

// const db = mongoose.connection;
// db.on('error', console.error.bind(console, 'connection error:'));
// db.once('open', function() {
//   // we're connected!
// //   console.log("we are connected")
// });
// const kittySchema = new mongoose.Schema({
//     userName:{
//        type: String,
//        required:true,
//        unique:true
//     },
       
//     firstName:{
//         type:String,
//         maxlength:12
//     } ,

//     lastName:{
//         type: String,
//         maxlength:12
//     },
//     email:{
//         type:String,
//         required:true,
//         unique:true,
//         validate(val){
//             if (validator.isEmail(val)){
//                 throw new Error("Email is not valid");
//             }
//         }
//     } ,
//     Gender:String,
//     isSeller:Boolean,
//     isAdmin:Boolean,
//     isCustomer:Boolean,
//     Passward:{
//       type:String,
//       required:true , 
//       maxlength:8
//     },
//     History: String
//   });

//   const Kitten = mongoose.model('Kitten', kittySchema);
//   const silence = new Kitten({ userName:'pappu', firstName: 'Silence' ,lastName:'Char',email:'190030026@iitdh.ac.in',Gender:'Male',isAdmin:true,isCustomer:true,isSeller:false,Passward:'Mayank@9269', History:'check my history'});
//   console.log(silence.firstName);
//   console.log(silence.lastName);
//   console.log(silence.email);
//   console.log(silence.userName);
//   console.log(silence.isAdmin);
//   console.log(silence.isCustomer);
//   console.log(silence.Gender);
//   console.log(silence.isSeller);
//   console.log(silence.Passward);
//   console.log(silence.History);